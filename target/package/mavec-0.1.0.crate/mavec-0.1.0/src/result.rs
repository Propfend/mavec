pub type Result<T> = std::result::Result<T, crate::error::MavecError>;
